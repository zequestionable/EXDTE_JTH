#01_variables
#Use sensible, descriptive variable names
#Variable names in Python are always lowercase
#Constant names are UPPERCASE
#Variables can include a mix of letters,
#underscores and numbers 
#(as long as the first character is not a number)

v4ar14b12 = "Weird Variable"
CONSTANT = "I love Computer Science"