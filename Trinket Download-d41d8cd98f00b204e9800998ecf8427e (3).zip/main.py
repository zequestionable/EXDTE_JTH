#get input
name = input("what is your name? ")
#ask user for two numbers
num_1 = int(input("what is your favourite number?"))
num_2 = int(input("what is your second favourite nuumber?"))
#add numbers together
add = num_1 + num_2 
#muiltiply numbers together
multi = num_1 * num_2 
#greet user and display math
print("Hello", name)

               

print("{} + {} = {}".format(num_1, num_2, add))   
print("{} * {} = {}".format(num_1, num_2, multi))   